google-traffic-disruptions.csv

This file contains the information for all disruptions displayed in the
"Disruption history" section of the Traffic and disruptions to Google
transparency report.

See https://transparencyreport.google.com/traffic/overview for more
information.
